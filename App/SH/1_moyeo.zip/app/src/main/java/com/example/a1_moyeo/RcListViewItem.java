package com.example.a1_moyeo;

public class RcListViewItem {
    private String rctitle;
    private String ingdate;
    private String grade;

    public void setRctitle(String RcTitle){ rctitle=RcTitle;}
    public void setIngdate(String IngDate){ingdate=IngDate;}
    public void setGrade(String Grade){grade=Grade;}
    public String getRctitle(){return this.rctitle;}
    public String getIngdate(){return this.ingdate;}
    public String getGrade(){return this.grade;}
}
