package com.example.libbb;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.support.v7.widget.Toolbar;

public class BookSearchActivity extends AppCompatActivity {
    //String TAG = "MyActivity";
    Spinner spinner;
    EditText write;
    Button search;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.booksearch);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("도서검색");
        setSupportActionBar(toolbar);
        spinner=findViewById(R.id.select);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"서명","저자명","출판사명"});
        spinner.setAdapter(adapter);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayHomeAsUpEnabled(true);

        write = (EditText) findViewById(R.id.write);
        search = (Button) findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Log.i(TAG,"write.getText() = "+write.getText());
                if(write.getText().toString().length()==0){
                    Intent intent = new Intent(getApplicationContext(),NoBookActivity.class);
                    startActivity(intent);
                }else {
                    Intent i = new Intent(getApplicationContext(),BookListActivity.class);
                    startActivity(i);
                }

            }
        });

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:{
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
}
