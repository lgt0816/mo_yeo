package com.example.libbb;

import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class BookListActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.booklist);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("자료검색");
        setSupportActionBar(toolbar);
        ListView listview;
        BookAdapter adapter;
        int[] img = {R.drawable.book,R.drawable.book1,R.drawable.book2};
        String[] title = {"책제목","책제목1","책제목2"};
        String[] writer = {"지은이","지은이1","지은이2"};
        String[] where = {"출판사","출판사1","출판사2"};

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayHomeAsUpEnabled(true);

        adapter = new BookAdapter();
        listview = (ListView) findViewById(R.id.listbook);
        listview.setAdapter(adapter);
        for(int i=0;i<img.length;i++){
            adapter.addItem(ContextCompat.getDrawable(this,img[i]),i+1,title[i],writer[i],where[i]);
        }
        /*adapter.addItem(ContextCompat.getDrawable(this,R.drawable.book),
                "1","책제목","지은이","출판사");
        adapter.addItem(ContextCompat.getDrawable(this,R.drawable.book),
                "2","책제목","지은이","출판사");
        adapter.addItem(ContextCompat.getDrawable(this,R.drawable.book),
                "3","책제목","지은이","출판사");*/

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),BookLookActivity.class);
                startActivity(intent);

            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:{
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
}
