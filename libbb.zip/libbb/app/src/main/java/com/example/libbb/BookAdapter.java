package com.example.libbb;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class BookAdapter extends BaseAdapter {
    private ArrayList<BookListViewItem> bookItemList = new ArrayList<BookListViewItem>();

    public BookAdapter(){

    }

    @Override
    public int getCount() {
        return bookItemList.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //postion = ListView의 위치      /   첫번째면 position = 0
        final int pos = position;
        final Context context = parent.getContext();


        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.custom_booklistview, parent, false);
        }

        ImageView bookImageView = (ImageView) convertView.findViewById(R.id.bookimg);
        TextView numTextView = (TextView) convertView.findViewById(R.id.number);
        TextView titleTextView = (TextView) convertView.findViewById(R.id.booktitle);
        TextView writerTextView = (TextView) convertView.findViewById(R.id.bookwriter);
        TextView whereTextView = (TextView) convertView.findViewById(R.id.bookwhere);

        BookListViewItem bookListViewItem = bookItemList.get(position);

        bookImageView.setImageDrawable(bookListViewItem.getImg());
        numTextView.setText(bookListViewItem.getNum()+"");
        titleTextView.setText(bookListViewItem.getTitle());
        writerTextView.setText(bookListViewItem.getWriter());
        whereTextView.setText(bookListViewItem.getWhere());

        return convertView;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return bookItemList.get(position);
    }
    public void addItem(Drawable Img, int Num, String Title, String Writer, String Where){
        BookListViewItem item = new BookListViewItem();

        item.setImg(Img);
        item.setNum(Num);
        item.setTitle(Title);
        item.setWriter(Writer);
        item.setWhere(Where);

        bookItemList.add(item);
    }

}
