package com.example.libbb;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class RoomAdapter extends BaseAdapter {
    private ArrayList<RoomListViewItem> roomListViewItemList = new ArrayList<RoomListViewItem>();

    public RoomAdapter(){}

    @Override
    public int getCount() {  return roomListViewItemList.size();    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //postion = ListView의 위치      /   첫번째면 position = 0
        final int pos = position;
        final Context context = parent.getContext();


        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.custom_roomlistview, parent, false);
        }
        TextView roomTextView = (TextView) convertView.findViewById(R.id.roomn);

        RoomListViewItem roomListViewItem = roomListViewItemList.get(position);

        roomTextView.setText(roomListViewItem.getRoomname());

        Button roomfind = (Button) convertView.findViewById(R.id.roomfind);
        roomfind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context.getApplicationContext(),GuideActivity.class);
                context.startActivity(intent);
            }
        });

        return convertView;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return roomListViewItemList.get(position);
    }
    public void addItem(String Roomname){
        RoomListViewItem item = new RoomListViewItem();

        item.setRoomname(Roomname);

        roomListViewItemList.add(item);
    }

}
