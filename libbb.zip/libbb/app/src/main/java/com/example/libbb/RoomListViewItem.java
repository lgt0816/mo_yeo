package com.example.libbb;

public class RoomListViewItem {
    private String roomname;

    public void setRoomname(String Roomname){roomname = Roomname;}
    public String getRoomname(){return this.roomname;}
}
