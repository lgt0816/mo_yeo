package com.example.libbb;

import android.graphics.drawable.Drawable;

public class BookListViewItem {
    private Drawable img;
    private int num;
    private String title;
    private String writer;
    private String where;

    public void setImg(Drawable Img){
        img = Img;
    }
    public void setNum(int Num){
        num = Num;
    }
    public void setTitle(String Title){
        title=Title;
    }
    public void setWriter(String Writer){
        writer=Writer;
    }
    public void setWhere(String Where){
        where=Where;
    }
    public Drawable getImg(){
        return this.img;
    }
    public int getNum(){
        return this.num;
    }
    public String getTitle(){
        return this.title;
    }
    public String getWriter(){
        return this.writer;
    }
    public String getWhere(){
        return this.where;
    }

}
