package com.myproject.japanese.domain;

import lombok.Data;

@Data
public abstract class Word {
	protected String meaning;

}
