package com.myproject.japanese.domain;

import org.springframework.web.multipart.MultipartFile;

import lombok.Getter;

@Getter
public class FileInfo {
	private MultipartFile file;
	private String fileName;
	private String fileType;
	
	public FileInfo(MultipartFile file) {
		this.file = file;
		this.fileName = file.getName();
		this.fileType = fileName.split(".")[1];
	}

}
