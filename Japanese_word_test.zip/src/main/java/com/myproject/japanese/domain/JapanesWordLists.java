package com.myproject.japanese.domain;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JapanesWordLists {
	
	private List<Word> nounWords1;	//음독명사 리스트
	private List<Word> nounWords2;	//훈독명사 리스트
	private List<Word> verbWords;	//동사 리스트
	private List<Word> iAdjectiveWords;	//い형용사 리스트
	private List<Word> naAdjectiveWords;	//な형용사 리스트
	private List<Word> adverbWrods;		//부사 리스트
	private List<Word> katakanaWords;	//카타카나 리스트
	
	public JapanesWordLists() {
		nounWords1 = new ArrayList<Word>();
		nounWords2 = new ArrayList<Word>();
		verbWords = new ArrayList<Word>();
		iAdjectiveWords = new ArrayList<Word>();
		naAdjectiveWords = new ArrayList<Word>();
		adverbWrods = new ArrayList<Word>();
		katakanaWords = new ArrayList<Word>();
	}
	
}
