package com.myproject.japanese.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.myproject.japanese.service.FileService;

@Controller
public class FileController {
	
	@Inject
	private FileService fileService;
	
	@RequestMapping(value = "/inputFile", method=RequestMethod.GET)
	public void inputFile() {
		
	}
	@RequestMapping(value = "/postInputFile", method=RequestMethod.POST)
	public String inputFilePost(HttpServletResponse response, @RequestParam("file") MultipartFile file) {
		fileService.doFileDownload(response, file);
//		String fileContentType = file.getContentType();
//		System.out.println(fileContentType);
		return "redirect:/";
	}

}
