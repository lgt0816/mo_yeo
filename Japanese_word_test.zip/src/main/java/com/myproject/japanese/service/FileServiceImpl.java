package com.myproject.japanese.service;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.myproject.japanese.domain.JapanesWordLists;
import com.myproject.japanese.domain.Kannzi;
import com.myproject.japanese.domain.Katakana;
import com.myproject.japanese.domain.Word;
import com.opencsv.CSVReader;

@Service
public class FileServiceImpl implements FileService{

	@Override
	public void doFileDownload(HttpServletResponse response, MultipartFile file) {
		//file.getContentType();
		
		JapanesWordLists words = convertToList(file);
		System.out.println("JapaneseWordList created!!!");
		System.out.println(words.getNounWords1().get(0).toString());
		
	}

	//구현완료
	@Override
	public JapanesWordLists convertToList(MultipartFile file) {
		String[] wordTypes = {"훈독명사", "음독명사", "동사", "い형용사", "な형용사", "부사및기타", "카타카나어"};
		int wordType= -1;
		JapanesWordLists wordLists = new JapanesWordLists();
		
		
		InputStreamReader inputStreamReader;
		
        
        List<String[]> list;
		
        try {
        	inputStreamReader = new InputStreamReader(file.getInputStream());
			CSVReader reader = new CSVReader(inputStreamReader);
			list = reader.readAll();
			
			OutLoop : for (String[] outForStr : list) {
				
				//단어 타입을 확인함
				for(int inForInt=0; inForInt<wordTypes.length;inForInt++) {
					if(outForStr[0].replaceAll(" ", "").equals(wordTypes[inForInt])) {
						wordType=inForInt;
						continue OutLoop;
					}
					
				}
				
				Word entity;
				
				switch(wordType){
					case 0:
						entity = new Kannzi(outForStr[0], outForStr[1], outForStr[2]);
						wordLists.getNounWords1().add(entity);
						break;
					case 1:
						entity = new Kannzi(outForStr[0], outForStr[1], outForStr[2]);
						wordLists.getNounWords2().add(entity);
						break;
					case 2:
						entity = new Kannzi(outForStr[0], outForStr[1], outForStr[2]);
						wordLists.getVerbWords().add(entity);
						break;
					case 3:
						entity = new Kannzi(outForStr[0], outForStr[1], outForStr[2]);
						wordLists.getIAdjectiveWords().add(entity);
						break;
					case 4:
						entity = new Kannzi(outForStr[0], outForStr[1], outForStr[2]);
						wordLists.getNaAdjectiveWords().add(entity);
						break;
					case 5:
						entity = new Kannzi(outForStr[0], outForStr[1], outForStr[2]);
						wordLists.getAdverbWrods().add(entity);
						break;
					case 6:
						entity = new Katakana(outForStr[0], outForStr[2]);
						wordLists.getKatakanaWords().add(entity);
						break;
				};

	        }
			return wordLists;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
        
        
	}

	@Override
	public HttpServletResponse makePdfFile(HttpServletResponse response, JapanesWordLists words) {
		
		return null;
	}


}
