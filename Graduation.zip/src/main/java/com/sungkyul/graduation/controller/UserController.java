package com.sungkyul.graduation.controller;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sungkyul.graduation.domain.User;
import com.sungkyul.graduation.dto.JoinDTO;
import com.sungkyul.graduation.dto.LoginDTO;
import com.sungkyul.graduation.service.UserService;


@Controller
public class UserController {
	 
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Inject
	private UserService service;
	
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public void login() throws Exception{
		logger.info("login GET....");
		
	}
	
	@RequestMapping(value="/loginPost", method = RequestMethod.POST)
	public void loginPost(LoginDTO dto, Model model) throws Exception{
		logger.info("loginPost={}", dto);
		
		try {
			User user = service.login(dto);
			logger.info("user={}",user);
			if(user != null) {
				//로그인 성공시
				model.addAttribute("user", user);
			}else {
				//로그인 실패시
				model.addAttribute("loginResult", "Login Fail!!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
		
	@RequestMapping(value = "/join", method = RequestMethod.GET)
	public void join() {
		logger.info("join GET....");
		
	}
	
	@RequestMapping(value = "/joinPost", method = RequestMethod.POST)
	public void joinPost(JoinDTO dto, Model model) {
		logger.info("joinPost={}", dto);
		
		try {
			if(service.join(dto)) {
				model.addAttribute("joinResult", "join Complite");
			}else {
				model.addAttribute("joinResult", "join Fail");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}

}
