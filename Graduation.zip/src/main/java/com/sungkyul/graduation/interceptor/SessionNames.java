package com.sungkyul.graduation.interceptor;

public interface SessionNames {
	final static String LOGIN = "loginUser";

}
