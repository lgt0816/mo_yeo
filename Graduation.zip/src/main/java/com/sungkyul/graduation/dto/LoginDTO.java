package com.sungkyul.graduation.dto;

import lombok.Data;

@Data
public class LoginDTO {
	private String userId;
	private String userPw;

}
