package com.myproject.japanese.domain;

public interface WordTypes {
	public static final String[] wordTypes = {"음독명사", "훈독명사", "동사", "い형용사", "な형용사", "부사및기타", "가타카나어"};
}
